class TaxBracket{

    constructor(range_start, range_end, rate)
    {

        this.range_start = parseInt(range_start);
        this.range_end = parseInt(range_end);
        this.rate = parseFloat(rate);

    }

}